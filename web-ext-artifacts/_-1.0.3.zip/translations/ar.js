const ar = {
  pluginName: "سرديّة",
  replacedWords: "الكلمات الأصلية",
  word: "الكلمة",
  replacement: "الأصل",
  wordLabel: "الكلمة",
  replacementLabel: "الأصل",
  submitButton: "حفظ الكلمة",
  cancelButton: "إلغاء",
  wordInput: "الكلمة التي تريد تعديلها",
  replacementInput: "الكلمة الاصلية",
  errorSubmissionFailed: "فشل في إرسال البيانات. يرجى المحاولة مرة أخرى.",
};

