//TODO: remove replaced words and reinsert original words from DOM

