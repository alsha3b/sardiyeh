const en = {
  pluginName: "Sardiya",
  replacedWords: "Replaced words",
  word: "Word",
  replacement: "Replacement",
  wordLabel: "Word",
  replacementLabel: "Replacement",
  submitButton: "Save",
  cancelButton: "Cancel",
  wordInput: "The word you want to replace",
  replacementInput: "The replacement for the word",
  errorSubmissionFailed: "Failed to submit the data. Please try again.",
};

